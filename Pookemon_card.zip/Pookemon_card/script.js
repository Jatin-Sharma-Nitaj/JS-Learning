let main = document.getElementById("main");
let arr = [
    "pokee1.jpg",
    "pokee2.jpg",
    "pokke3.jpg",
    "pokee4.jpg",
    "pokee5.jpg",
    "pokee6.jpg",
    "pokee7.jpg",
];
let s = "";
for (let i = 1; i <= 70; i++) {
  let r =Math.floor( Math.random()*arr.length);
  s+=`<div class = "card"><img src = ${arr[r]}></div>`;
   }

 
main.innerHTML = s;

// Select elements
var input = document.querySelector(".input-field");
var btn = document.querySelector("button");
var ul = document.querySelector(".todo-list");

btn.addEventListener('click', function() {
    const taskText = input.value.trim(); 
    
    if (taskText !== "") { 
        // Create a new list item
        const listItem = document.createElement('li');
        listItem.textContent = taskText; // Set list item's text

        // Add list item to the todo list
        ul.appendChild(listItem);

        // Clear the input field
        input.value = '';
    } else {
        alert("Kya Kam h be?"); 
    }
});

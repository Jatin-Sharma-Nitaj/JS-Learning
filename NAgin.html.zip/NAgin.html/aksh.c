#include<stdio.h>
#include<conio.h>
main (){//error
   int i,intj;
    for(i=0;j=5;i++)
    return 0;// half program
}

ef6060a26a0c5a2ffd8fa13e
// Country list (abbreviated for simplicity)
const countryList = {
    USD: "US",
    INR: "IN",
    EUR: "EU",
    GBP: "GB",
    JPY: "JP",
  };
  
  // Access DOM elements
  const amountInput = document.getElementById('amount');
  const fromCurrencyDropdown = document.getElementById('from-currency');
  const toCurrencyDropdown = document.getElementById('to-currency');
  const convertButton = document.getElementById('convert-btn');
  const resultDisplay = document.getElementById('result');
  
  // Populate dropdowns with currencies
  Object.keys(countryList).forEach(currency => {
    const optionFrom = document.createElement('option');
    const optionTo = document.createElement('option');
  
    optionFrom.value = currency;
    optionFrom.textContent = currency;
  
    optionTo.value = currency;
    optionTo.textContent = currency;
  
    fromCurrencyDropdown.appendChild(optionFrom);
    toCurrencyDropdown.appendChild(optionTo);
  });
  
  // Set default values
  fromCurrencyDropdown.value = 'USD';
  toCurrencyDropdown.value = 'INR';
  
  // Event listener for conversion
  convertButton.addEventListener('click', () => {
    const amount = parseFloat(amountInput.value);
    const fromCurrency = fromCurrencyDropdown.value;
    const toCurrency = toCurrencyDropdown.value;
  
    if (isNaN(amount) || amount <= 0) {
      resultDisplay.textContent = 'Please enter a valid amount.';
      return;
    }
  
    const apiUrl = `https://api.exchangerate-api.com/v4/latest/${fromCurrency}`;
  
    fetch(apiUrl)
      .then(response => response.json())
      .then(data => {
        const rate = data.rates[toCurrency];
        if (!rate) {
          resultDisplay.textContent = `Conversion rate not available for ${toCurrency}.`;
          return;
        }
  
        const convertedAmount = (amount * rate).toFixed(2);
        resultDisplay.textContent = `${amount} ${fromCurrency} = ${convertedAmount} ${toCurrency}`;
      })
      .catch(error => {
        console.error('Error fetching exchange rates:', error);
        resultDisplay.textContent = 'Could not fetch exchange rates. Try again later.';
      });
  });
  